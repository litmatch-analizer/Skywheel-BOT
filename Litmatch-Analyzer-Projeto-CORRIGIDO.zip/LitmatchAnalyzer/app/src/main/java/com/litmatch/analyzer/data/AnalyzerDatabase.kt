package com.litmatch.analyzer.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [ResultEntity::class], version = 1, exportSchema = false)
abstract class AnalyzerDatabase : RoomDatabase() {
    abstract fun resultDao(): ResultDao
    companion object {
        @Volatile private var INSTANCE: AnalyzerDatabase? = null
        fun get(context: Context): AnalyzerDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context, AnalyzerDatabase::class.java, "analyzer.db").build().also { INSTANCE = it }
        }
    }
}
