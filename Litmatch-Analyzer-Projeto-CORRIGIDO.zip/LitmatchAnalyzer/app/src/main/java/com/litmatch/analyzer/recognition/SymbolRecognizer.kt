package com.litmatch.analyzer.recognition

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc

data class Recognition(val symbol: String?, val confidence: Float)

class SymbolRecognizer(context: Context) {
    private val templates = linkedMapOf<String, Mat>()
    init {
        System.loadLibrary("opencv_java4")
        val names = listOf("camera","crown","ice_cream","lifebuoy","balloons","boxing_glove","teddy_bear","princess")
        names.forEach { name ->
            context.assets.open("templates/$name.png").use { input ->
                val bmp = BitmapFactory.decodeStream(input)
                val mat = Mat()
                Utils.bitmapToMat(bmp, mat)
                Imgproc.cvtColor(mat, mat, Imgproc.COLOR_RGBA2GRAY)
                templates[name] = mat
                bmp.recycle()
            }
        }
    }

    // Frame stays in memory. Returns null when the best match is below the conservative threshold.
    fun recognize(frame: Bitmap): Recognition {
        val source = Mat()
        Utils.bitmapToMat(frame, source)
        val gray = Mat()
        Imgproc.cvtColor(source, gray, Imgproc.COLOR_RGBA2GRAY)
        var bestName: String? = null
        var best = -1.0
        for ((name, template) in templates) {
            for (scale in listOf(0.70, 0.85, 1.0, 1.15, 1.30)) {
                val resized = Mat()
                Imgproc.resize(template, resized, Size(template.cols()*scale, template.rows()*scale))
                if (resized.cols() >= gray.cols() || resized.rows() >= gray.rows()) { resized.release(); continue }
                val result = Mat()
                Imgproc.matchTemplate(gray, resized, result, Imgproc.TM_CCOEFF_NORMED)
                val mm = Core.minMaxLoc(result)
                if (mm.maxVal > best) { best = mm.maxVal; bestName = name }
                resized.release(); result.release()
            }
        }
        source.release(); gray.release()
        return if (best >= 0.86) Recognition(bestName, best.toFloat()) else Recognition(null, best.toFloat().coerceAtLeast(0f))
    }
}
