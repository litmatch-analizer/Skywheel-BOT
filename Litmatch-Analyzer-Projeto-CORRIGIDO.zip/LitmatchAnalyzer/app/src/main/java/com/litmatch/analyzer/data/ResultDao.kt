package com.litmatch.analyzer.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ResultDao {
    @Query("SELECT * FROM round_results ORDER BY timestamp DESC")
    fun observeAll(): Flow<List<ResultEntity>>
    @Query("SELECT MAX(roundNumber) FROM round_results")
    suspend fun lastRound(): Int?
    @Insert
    suspend fun insert(item: ResultEntity)
    @Query("SELECT * FROM round_results ORDER BY timestamp DESC LIMIT 1")
    suspend fun latest(): ResultEntity?
}
