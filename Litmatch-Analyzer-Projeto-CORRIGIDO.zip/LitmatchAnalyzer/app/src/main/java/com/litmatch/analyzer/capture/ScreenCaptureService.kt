package com.litmatch.analyzer.capture

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import com.litmatch.analyzer.data.AnalyzerDatabase
import com.litmatch.analyzer.data.ResultEntity
import com.litmatch.analyzer.recognition.SymbolRecognizer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.nio.ByteBuffer

class ScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var thread: HandlerThread? = null
    private var recognizer: SymbolRecognizer? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var lastAccepted = ""
    private var lastAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotification()
        val code = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra("data", Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra("data")
        }
        if (code != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(code, data)
        recognizer = try { SymbolRecognizer(this) } catch (_: Exception) { null }
        startFrames()
        return START_NOT_STICKY
    }

    private fun createNotification() {
        val channel = "capture"
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(channel, "Captura temporária", NotificationManager.IMPORTANCE_LOW))
        val notification = Notification.Builder(this, channel).setContentTitle("Litmatch Analyzer").setContentText("Analisando quadros temporários em memória").setSmallIcon(android.R.drawable.ic_menu_view).build()
        startForeground(7, notification)
    }

    private fun startFrames() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION") (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val w = metrics.widthPixels; val h = metrics.heightPixels; val dpi = metrics.densityDpi
        thread = HandlerThread("frame-memory").also { it.start() }
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader!!.setOnImageAvailableListener({ source ->
            val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val plane = image.planes[0]
                val buffer: ByteBuffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val padded = Bitmap.createBitmap(rowStride / pixelStride, h, Bitmap.Config.ARGB_8888)
                padded.copyPixelsFromBuffer(buffer)
                val frame = Bitmap.createBitmap(padded, 0, 0, w, h)
                padded.recycle()
                val found = recognizer?.recognize(frame)
                frame.recycle()
                val now = System.currentTimeMillis()
                if (found != null && now-lastAt > 5000 &&
                    (found.symbol == null || found.symbol != lastAccepted)) {
                    lastAccepted = found.symbol ?: "unknown"
                    lastAt = now
                    scope.launch {
                        val dao = AnalyzerDatabase.get(this@ScreenCaptureService).resultDao()
                        val round = (dao.lastRound() ?: 0) + 1
                        dao.insert(ResultEntity(
                            roundNumber = round,
                            symbol = found.symbol ?: "unknown",
                            confidence = found.confidence,
                            source = "captura"
                        ))
                    }
                }
            } catch (_: Exception) { /* Frame descartado; nenhum arquivo é criado. */ }
            finally { image.close() }
        }, Handler(thread!!.looper))
        display = projection?.createVirtualDisplay("LitmatchAnalyzer", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)
    }

    override fun onDestroy() {
        display?.release(); reader?.close(); projection?.stop(); thread?.quitSafely()
        super.onDestroy()
    }
}
