package com.litmatch.analyzer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.litmatch.analyzer.capture.ScreenCaptureService
import com.litmatch.analyzer.data.*
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

val Symbols = listOf("camera","crown","ice_cream","lifebuoy","balloons","boxing_glove","teddy_bear","princess")
val Labels = mapOf("camera" to "Câmera","crown" to "Coroa","ice_cream" to "Sorvete","lifebuoy" to "Boia","balloons" to "Balões","boxing_glove" to "Luva","teddy_bear" to "Urso","princess" to "Princesa")
val Bg = Color(0xFF0D0B16); val Panel = Color(0xFF191526); val Accent = Color(0xFF9B75FF); val Mint = Color(0xFF55E6D0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { AnalyzerApp(this) } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun AnalyzerApp(activity: Activity) {
    val dao = remember { AnalyzerDatabase.get(activity).resultDao() }
    var results by remember { mutableStateOf(emptyList<ResultEntity>()) }
    var selected by remember { mutableStateOf(Symbols.first()) }
    var round by remember { mutableStateOf("1322") }
    val scope = rememberCoroutineScope()
    val captureLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val service = Intent(activity, ScreenCaptureService::class.java).putExtra("resultCode", result.resultCode).putExtra("data", result.data)
            if (Build.VERSION.SDK_INT >= 26) activity.startForegroundService(service) else activity.startService(service)
        }
    }
    LaunchedEffect(Unit) { dao.observeAll().collectLatest { results = it; round = ((it.maxOfOrNull { r -> r.roundNumber } ?: 1321)+1).toString() } }
    val counts = Symbols.associateWith { s -> results.count { it.symbol == s } }
    val total = results.size
    val ranked = Symbols.sortedByDescending { counts[it] ?: 0 }
    val picks = ranked.take(4).let { if (it.size < 4) (it + Symbols.filterNot { s -> it.contains(s) }.take(4-it.size)) else it }
    MaterialTheme(colorScheme = darkColorScheme(primary=Accent, background=Bg, surface=Panel)) {
        Column(Modifier.fillMaxSize().background(Bg).padding(16.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text("LITMATCH ANALYZER", color=Color.White, fontWeight=FontWeight.Bold); Text("Painel estatístico", color=Color.Gray, style=MaterialTheme.typography.bodySmall) }
                Surface(color=Color(0xFF263C39), shape=RoundedCornerShape(30.dp)) { Text("● LOCAL", Modifier.padding(horizontal=12.dp, vertical=7.dp), color=Mint, style=MaterialTheme.typography.labelSmall) }
            }
            Spacer(Modifier.height(18.dp))
            Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Resumo do histórico", color=Color.LightGray)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) {
                        Metric("Rodadas", "$total"); Metric("Símbolos", "${results.map{it.symbol}.distinct().size}/8"); Metric("Última rodada", results.firstOrNull()?.roundNumber?.toString() ?: "—")
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Text("4 tendências estatísticas", color=Color.White, fontWeight=FontWeight.Bold)
            Text("Baseadas somente nos resultados registrados; não são previsões garantidas.", color=Color.Gray, style=MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                picks.forEachIndexed { i,s -> Card(Modifier.weight(1f), colors=CardDefaults.cardColors(containerColor=Panel)) { Column(Modifier.padding(9.dp), horizontalAlignment=Alignment.CenterHorizontally) { Text("#${i+1}", color=Accent); Text(Labels[s] ?: s, color=Color.White, style=MaterialTheme.typography.labelMedium); Text("${counts[s] ?: 0}", color=Mint, fontWeight=FontWeight.Bold) } } }
            }
            Spacer(Modifier.height(16.dp))
            Text("Registrar resultado", color=Color.White, fontWeight=FontWeight.Bold)
            var roundInput by remember { mutableStateOf(round) }
            LaunchedEffect(round) { roundInput = round }
            OutlinedTextField(value=roundInput, onValueChange={roundInput=it.filter(Char::isDigit)}, label={Text("Número da rodada")}, singleLine=true, modifier=Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            var expanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(expanded=expanded, onExpandedChange={expanded=it}) {
                OutlinedTextField(value=Labels[selected] ?: selected, onValueChange={}, readOnly=true, label={Text("Símbolo identificado")}, trailingIcon={ExposedDropdownMenuDefaults.TrailingIcon(expanded)}, modifier=Modifier.menuAnchor().fillMaxWidth())
                ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) { Symbols.forEach { s -> DropdownMenuItem(text={Text(Labels[s] ?: s)},onClick={selected=s;expanded=false}) } }
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick={ scope.launch { val n=roundInput.toIntOrNull(); if(n!=null) dao.insert(ResultEntity(roundNumber=n,symbol=selected,confidence=1f,source="manual")) } }, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Salvar resultado") }
            OutlinedButton(onClick={ val mgr=activity.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager; captureLauncher.launch(mgr.createScreenCaptureIntent()) }, modifier=Modifier.fillMaxWidth()) { Icon(Icons.Default.ScreenShare,null); Spacer(Modifier.width(8.dp)); Text("Iniciar captura temporária") }
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment=Alignment.CenterVertically) { Text("Histórico", color=Color.White, fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f)); Text("$total registros", color=Color.Gray, style=MaterialTheme.typography.labelSmall) }
            LazyColumn(Modifier.weight(1f), verticalArrangement=Arrangement.spacedBy(6.dp)) {
                items(results.take(100)) { item -> Card(colors=CardDefaults.cardColors(containerColor=Panel)) { Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment=Alignment.CenterVertically) { Text("#${item.roundNumber}", color=Accent, modifier=Modifier.weight(1f)); Text(Labels[item.symbol] ?: "Não identificado", color=Color.White, modifier=Modifier.weight(1f)); Text(if(item.source=="captura") "Captura" else "Manual", color=Color.Gray, style=MaterialTheme.typography.labelSmall) } } }
            }
        }
    }
}
@Composable fun Metric(label:String,value:String) { Column { Text(value,color=Color.White,fontWeight=FontWeight.Bold,style=MaterialTheme.typography.titleLarge); Text(label,color=Color.Gray,style=MaterialTheme.typography.labelSmall) } }
