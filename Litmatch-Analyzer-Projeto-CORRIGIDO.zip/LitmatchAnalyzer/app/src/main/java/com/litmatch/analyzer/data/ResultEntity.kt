package com.litmatch.analyzer.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "round_results")
data class ResultEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val roundNumber: Int,
    val symbol: String,
    val confidence: Float,
    val source: String,
    val timestamp: Long = System.currentTimeMillis()
)
