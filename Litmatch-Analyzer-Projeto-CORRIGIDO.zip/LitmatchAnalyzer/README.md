# Litmatch Analyzer

Aplicativo Android nativo (Kotlin + Jetpack Compose), com banco Room local e captura MediaProjection.

## O que está implementado
- Cadastro manual de resultados, com rodada, horário automático, origem e símbolo.
- Histórico local e contagem de frequência dos oito símbolos identificados na imagem enviada.
- Quatro tendências estatísticas calculadas a partir da frequência registrada.
- Captura de tela via MediaProjection, com quadros mantidos em memória e descartados após análise.
- Templates de reconhecimento extraídos somente para identificação dos símbolos.
- Workflow GitHub Actions para gerar APK debug.

## Símbolos
`camera`, `crown`, `ice_cream`, `lifebuoy`, `balloons`, `boxing_glove`, `teddy_bear`, `princess`.

## Gerar APK pelo GitHub
1. Crie um repositório vazio no GitHub.
2. Envie todo o conteúdo deste ZIP para a raiz do repositório.
3. Abra **Actions** e execute **Build Android APK** (ou faça push na branch main).
4. Baixe o artefato `litmatch-analyzer-debug-apk`.

## Requisitos
- Android Studio recente para compilação local.
- Android 8.0+ (minSdk 26); targetSdk 35 (Android 15).
- GitHub Actions usa JDK 17 e Gradle 8.9.

## Privacidade
A captura usa MediaProjection com consentimento do sistema. Os frames são convertidos em Bitmap em memória e descartados; o app não grava vídeo, screenshot ou frame em galeria/armazenamento. O Room armazena somente resultados e metadados estatísticos. O Android pode manter dados internos do app no armazenamento privado, mas nenhum arquivo de mídia é criado.

## Limitações importantes da versão inicial
- O reconhecimento usa correspondência de modelos visuais (OpenCV) obtidos de uma única captura. Mudanças de escala, animações, efeitos ou layout podem reduzir a precisão. O limite é conservador (0,86); quando não alcança o limite, a API retorna `symbol = null`.
- A primeira implementação de captura registra símbolos reconhecidos, mas não faz leitura OCR do número da rodada nem deduplicação robusta de eventos/rodadas. O número da rodada é incrementado localmente.
- As quatro tendências são os quatro símbolos mais frequentes no histórico, com preenchimento neutro quando há poucos dados. Isso não prevê resultados aleatórios nem garante acertos.
- A avaliação de acertos/erros por rodada, intervalos avançados e painel de taxa de acerto ainda precisam de implementação e testes em aparelho real.
- Este ambiente não possui Android SDK nem Gradle instalado; portanto, o APK não foi compilado nem testado em dispositivo nesta entrega. O workflow está preparado para realizar a compilação no GitHub Actions.

## Segurança e transparência
O app não faz apostas nem interage com o Litmatch. É uma ferramenta local de registro e análise descritiva. Resultados não identificados não devem ser tratados como símbolos confirmados.
